# Bot de Discord + SA-MP (Base em Python)

Este projeto é uma **base** de bot para Discord em Python, integrado a uma API de SA-MP e com sistema de **roleta diária** de recompensas, incluindo **canal de logs** para registrar cada giro.

## Funcionalidades

- Consulta da quantidade de jogadores online no servidor SA-MP via API.
- Comando `!online` para exibir o status do servidor.
- Sistema de roleta diária (`!roleta`):
  - Cada usuário pode girar **1 vez a cada X horas** (configurável).
  - Recompensas totalmente configuráveis em `config.py`.
  - Registro em arquivo (`data/roulette.json`) das datas de giro.
- Canal de logs configurável:
  - Registra automaticamente cada giro, com:
    - Usuário
    - Horário
    - Prêmio recebido

## Requisitos

- Python 3.10+ (recomendado).
- Um bot criado no portal do Discord (Developer Portal) com o token configurado.
- Biblioteca `discord.py` 2.x.
- Biblioteca `aiohttp` para chamadas HTTP.

Instale as dependências com:

```bash
pip install -r requirements.txt
```

## Arquivos principais

- `main.py`  
  Ponto de entrada do bot. Carrega os cogs e inicia o bot.

- `config.py`  
  Arquivo de configuração:
  - `DISCORD_TOKEN`: token do bot do Discord.
  - `SAMP_API_URL`: URL da API do seu servidor SA-MP.
  - `ROULETTE_COOLDOWN_HOURS`: intervalo de tempo entre giros por usuário.
  - `LOG_CHANNEL_ID`: ID do canal de logs no Discord.
  - `REWARDS`: lista de recompensas da roleta.

- `cogs/samp_status.py`  
  Implementa o comando `!online`, que consulta a API SA-MP e mostra os jogadores online.

- `cogs/roulette.py`  
  Implementa o comando `!roleta`, controle de cooldown, seleção de recompensa e envio de logs.

- `data/roulette.json`  
  Arquivo de armazenamento simples (JSON) para os últimos giros por usuário.

## Comandos

- `!online`  
  Mostra o status / quantidade de jogadores online no servidor SA-MP.

- `!roleta`  
  Gira a roleta de recompensas (respeitando o cooldown configurado).

## Como usar

1. Extraia o `.zip` do projeto.
2. Edite o arquivo `config.py`:
   - Coloque o token do seu bot em `DISCORD_TOKEN`.
   - Coloque a URL correta da API do seu servidor SA-MP em `SAMP_API_URL`.
   - Configure o ID do canal de logs em `LOG_CHANNEL_ID` (ou deixe 0 para não logar em canal).
   - Ajuste a lista de recompensas em `REWARDS` conforme seu projeto.
3. Instale as dependências:
   ```bash
   pip install -r requirements.txt
   ```
4. Execute o bot:
   ```bash
   python main.py
   ```

## Integração com o seu servidor SA-MP

- No comando de roleta, o embed retorna campos de **dados internos** (`type` e `value`) que você pode usar
  para integrar com a lógica do seu servidor (ex: dar dinheiro, VIP, item, etc.).
- Você pode:
  - Criar uma API no seu gamemode que receba o ID do jogador/conta e o prêmio.
  - Ou usar um script externo para registrar em um banco de dados lido pelo servidor SA-MP.

Esta base foi pensada para ser **simples, segura e facilmente configurável**, servindo como ponto de partida
para o seu projeto.