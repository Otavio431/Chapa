import json
    from pathlib import Path
    from typing import Any

    import discord
    from discord.ext import commands

    import config
    from datetime import datetime, timedelta, timezone
    import random
    import asyncio


    DATA_DIR = Path("data")
    DATA_FILE = DATA_DIR / "roulette.json"

    _file_lock = asyncio.Lock()


    def _utc_now() -> datetime:
        return datetime.now(timezone.utc)


    def _ensure_data_file_exists() -> None:
        DATA_DIR.mkdir(parents=True, exist_ok=True)
        if not DATA_FILE.exists():
            DATA_FILE.write_text(json.dumps({"users": {}}, indent=4), encoding="utf-8")


    async def _load_data() -> dict[str, Any]:
        _ensure_data_file_exists()
        async with _file_lock:
            raw = DATA_FILE.read_text(encoding="utf-8")
            try:
                return json.loads(raw)
            except json.JSONDecodeError:
                return {"users": {}}


    async def _save_data(data: dict[str, Any]) -> None:
        async with _file_lock:
            DATA_FILE.write_text(json.dumps(data, indent=4, ensure_ascii=False), encoding="utf-8")


    def _select_reward() -> dict:
        """Seleciona uma recompensa com base no peso definido em config.REWARDS."""
        rewards = config.REWARDS
        weights = [r.get("weight", 1) for r in rewards]
        total_weight = sum(weights)
        if total_weight <= 0:
            # fallback: chance igual para todos
            weights = [1 for _ in rewards]

        # random.choices faz seleção ponderada
        chosen = random.choices(rewards, weights=weights, k=1)[0]
        return chosen


    class Roulette(commands.Cog):
        """Sistema de roleta diária de recompensas."""  # noqa: D401

        def __init__(self, bot: commands.Bot):
            self.bot = bot

        # region Utilitários de cooldown

        @staticmethod
        def _get_user_last_spin(data: dict[str, Any], user_id: int) -> datetime | None:
            users = data.get("users", {})
            user_info = users.get(str(user_id))
            if not user_info:
                return None

            ts = user_info.get("last_spin")
            if ts is None:
                return None

            try:
                return datetime.fromtimestamp(ts, tz=timezone.utc)
            except Exception:
                return None

        @staticmethod
        def _set_user_last_spin(data: dict[str, Any], user_id: int, dt: datetime) -> None:
            users = data.setdefault("users", {})
            users[str(user_id)] = {
                "last_spin": dt.timestamp()
            }

        @staticmethod
        def _format_timedelta(delta: timedelta) -> str:
            total_seconds = int(delta.total_seconds())
            if total_seconds <= 0:
                return "agora"

            hours, remainder = divmod(total_seconds, 3600)
            minutes, seconds = divmod(remainder, 60)

            parts: list[str] = []
            if hours:
                parts.append(f"{hours}h")
            if minutes:
                parts.append(f"{minutes}min")
            if seconds and not hours and not minutes:
                parts.append(f"{seconds}s")

            return " ".join(parts) if parts else "alguns segundos"

        # endregion

        async def _log_spin(
            self,
            user: discord.abc.User,
            reward: dict,
            spin_time: datetime,
            guild: discord.Guild | None,
        ) -> None:
            """Envia log da roleta para o canal configurado, se existir."""
            channel_id = config.LOG_CHANNEL_ID
            if not channel_id:
                # Sem canal configurado, apenas loga no console
                print(f"[ROULET LOG] {spin_time.isoformat()} - {user} ganhou: {reward['name']}")
                return

            channel = self.bot.get_channel(channel_id)
            if channel is None and guild is not None:
                # Tentativa de buscar pelo servidor, caso o bot esteja nele
                try:
                    channel = await guild.fetch_channel(channel_id)  # type: ignore[arg-type]
                except Exception:
                    channel = None

            if channel is None:
                print(f"[ROULET LOG] Canal de logs {channel_id} não encontrado.")
                print(f"[ROULET LOG] {spin_time.isoformat()} - {user} ganhou: {reward['name']}")
                return

            embed = discord.Embed(
                title="Giro de Roleta Registrado",
                description=f"{user.mention} realizou um giro na roleta.",
            )
            embed.add_field(name="Usuário", value=f"{user} (ID: {user.id})", inline=False)
            embed.add_field(name="Prêmio", value=reward.get("name", "Desconhecido"), inline=False)
            embed.add_field(
                name="Detalhes",
                value=reward.get("description") or "Sem descrição adicional.",
                inline=False,
            )
            embed.timestamp = spin_time

            await channel.send(embed=embed)

        @commands.command(name="roleta")
        @commands.cooldown(1, 5, commands.BucketType.user)
        async def roulette_command(self, ctx: commands.Context):
            """Gira a roleta de recompensas (1x a cada 24h por usuário)."""
            await ctx.trigger_typing()

            user = ctx.author
            now = _utc_now()
            cooldown = timedelta(hours=config.ROULETTE_COOLDOWN_HOURS)

            data = await _load_data()
            last_spin = self._get_user_last_spin(data, user.id)

            if last_spin is not None:
                elapsed = now - last_spin
                if elapsed < cooldown:
                    remaining = cooldown - elapsed
                    fmt = self._format_timedelta(remaining)
                    await ctx.send(
                        f"Você já girou a roleta nas últimas {config.ROULETTE_COOLDOWN_HOURS}h.
"
                        f"Tente novamente em **{fmt}**."
                    )
                    return

            # Seleciona recompensa
            reward = _select_reward()

            # Atualiza data
            self._set_user_last_spin(data, user.id, now)
            await _save_data(data)

            # Monta embed do resultado
            embed = discord.Embed(
                title="🎰 Roleta de Recompensas",
                description=f"{user.mention} girou a roleta!",
            )
            embed.add_field(
                name="Prêmio recebido",
                value=reward.get("name", "Prêmio desconhecido"),
                inline=False,
            )

            description = reward.get("description")
            if description:
                embed.add_field(
                    name="Detalhes",
                    value=description,
                    inline=False,
                )

            reward_type = reward.get("type")
            value = reward.get("value")

            detalhes_tecnicos = []
            if reward_type:
                detalhes_tecnicos.append(f"Tipo interno: `{reward_type}`")
            if value is not None:
                detalhes_tecnicos.append(f"Valor interno: `{value}`")

            if detalhes_tecnicos:
                embed.add_field(
                    name="Dados para integração",
                    value="\n".join(detalhes_tecnicos),
                    inline=False,
                )

            embed.set_footer(text="Integre este prêmio ao seu sistema SA-MP pela API ou scripts internos.")
            embed.timestamp = now

            await ctx.send(embed=embed)

            # Envia log para canal configurado
            await self._log_spin(user=user, reward=reward, spin_time=now, guild=ctx.guild)


    async def setup(bot: commands.Bot):
        await bot.add_cog(Roulette(bot))