import aiohttp
from discord.ext import commands
import discord

import config


class SampStatus(commands.Cog):
    """Comandos relacionados ao servidor SA-MP (status, jogadores online, etc.)."""  # noqa: D401

    def __init__(self, bot: commands.Bot):
        self.bot = bot

    async def fetch_samp_status(self) -> dict | None:
        """Consulta a API do servidor SA-MP e retorna os dados (ou None em caso de erro)."""
        if not config.SAMP_API_URL:
            return None

        try:
            async with aiohttp.ClientSession() as session:
                async with session.get(config.SAMP_API_URL, timeout=5) as resp:
                    if resp.status != 200:
                        return None
                    data = await resp.json()
                    return data
        except Exception:
            return None

    @commands.command(name="online")
    async def online_command(self, ctx: commands.Context):
        """Mostra a quantidade de jogadores online no servidor SA-MP."""
        await ctx.trigger_typing()
        data = await self.fetch_samp_status()

        if not data:
            await ctx.send("Não foi possível consultar o status do servidor SA-MP no momento.")
            return

        players_online = data.get("players_online")
        max_players = data.get("max_players")
        hostname = data.get("hostname", "Servidor SA-MP")

        embed = discord.Embed(
            title="Status do Servidor SA-MP",
            description=hostname,
        )

        if players_online is not None and max_players is not None:
            embed.add_field(
                name="Jogadores online",
                value=f"{players_online}/{max_players}",
                inline=False,
            )
        elif players_online is not None:
            embed.add_field(
                name="Jogadores online",
                value=str(players_online),
                inline=False,
            )
        else:
            embed.add_field(
                name="Jogadores online",
                value="Informação não disponível",
                inline=False,
            )

        await ctx.send(embed=embed)


async def setup(bot: commands.Bot):
    await bot.add_cog(SampStatus(bot))