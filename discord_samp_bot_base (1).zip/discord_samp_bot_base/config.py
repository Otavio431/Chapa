"""Configuração básica do bot de Discord + SA-MP.

Ajuste os valores conforme o seu projeto.
"""

# Token do bot do Discord
DISCORD_TOKEN: str = "COLOQUE_SEU_TOKEN_AQUI"

# URL da API do servidor SA-MP
# Exemplo esperado de resposta (JSON):
# {
#   "hostname": "Nome do servidor",
#   "players_online": 45,
#   "max_players": 100
# }
SAMP_API_URL: str = "https://sua-api-samp-aqui.com/status"

# Cooldown da roleta (em horas)
ROULETTE_COOLDOWN_HOURS: int = 24

# ID do canal de logs (substitua pelo ID real do canal no servidor)
# Se estiver como 0 ou None, o bot não enviará logs para canal, apenas no console.
LOG_CHANNEL_ID: int | None = 0

# Lista de recompensas da roleta.
# Você pode adaptar isso ao seu sistema (itens in-game, moedas, VIP, etc).
# A chave "weight" define a chance relativa de cair (quanto maior, mais comum).
REWARDS: list[dict] = [
    {
        "name": "50.000 de dinheiro",
        "type": "money",
        "value": 50000,
        "weight": 40,
        "description": "Uma quantia básica para começar bem."
    },
    {
        "name": "100.000 de dinheiro",
        "type": "money",
        "value": 100000,
        "weight": 25,
        "description": "Um bom impulso financeiro."
    },
    {
        "name": "Item raro",
        "type": "item",
        "value": "item_raro_id",
        "weight": 10,
        "description": "Um item especial de baixa chance."
    },
    {
        "name": "VIP 1 dia",
        "type": "vip",
        "value": 1,
        "weight": 8,
        "description": "VIP temporário para testar os benefícios."
    },
    {
        "name": "VIP 3 dias",
        "type": "vip",
        "value": 3,
        "weight": 5,
        "description": "VIP com duração maior."
    },
    {
        "name": "SUPER PRÊMIO: 500.000 de dinheiro",
        "type": "money",
        "value": 500000,
        "weight": 2,
        "description": "Extremamente raro, recompensa insana."
    },
    {
        "name": "NADA (azar!)",
        "type": "none",
        "value": None,
        "weight": 10,
        "description": "Dessa vez não deu, mas tente de novo amanhã."
    },
]