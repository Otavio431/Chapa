import discord
from discord.ext import commands
import config


def create_bot() -> commands.Bot:
    intents = discord.Intents.default()
    intents.message_content = True  # Necessário para ler mensagens e comandos baseados em texto

    bot = commands.Bot(
        command_prefix="!",
        intents=intents,
        help_command=commands.DefaultHelpCommand(no_category='Comandos gerais')
    )
    return bot


bot = create_bot()


@bot.event
async def setup_hook():
    # Carrega as extensões (cogs)
    await bot.load_extension("cogs.samp_status")
    await bot.load_extension("cogs.roulette")


@bot.event
async def on_ready():
    print(f"Bot conectado como {bot.user} (ID: {bot.user.id})")
    print("Servidores:")
    for guild in bot.guilds:
        print(f"- {guild.name} (ID: {guild.id})")


if __name__ == "__main__":
    if not config.DISCORD_TOKEN or config.DISCORD_TOKEN == "COLOQUE_SEU_TOKEN_AQUI":
        raise RuntimeError("Configure o DISCORD_TOKEN em config.py antes de iniciar o bot.")
    bot.run(config.DISCORD_TOKEN)